Welcome to the Novaris initrd!

This file was loaded from a custom archive format (see
userland/mkinitrd.py) via a GRUB multiboot module, parsed by
kernel/initrd.c, and is being read right now through the generic VFS
layer in kernel/vfs.c.

Try:
  ls               - list every file in here
  cat hello.txt    - print a file to the screen
  run helloc.bin   - load and execute a flat-binary ring-3 program
  run helloelf.elf - load and execute a *real ELF executable*, which
                     also exercises the new mmap-equivalent syscall
                     (see ROADMAP.md's Milestone 8 notes)
