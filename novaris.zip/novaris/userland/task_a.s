; task_a.s - tiny demo user-mode program for the Milestone 9 preemptive
; scheduler: loops printing a short tag with a busy-wait spin between
; each print, so a single scheduler time slice can't race through all
; iterations before the timer ever gets a chance to preempt it - without
; the spin, a tight print loop finishes so fast relative to a 10-20ms
; slice that one task can grab a large head start before the others get
; scheduled at all. Multiple copies of this program (task_a/b/c) running
; concurrently produce visibly interleaved output if - and only if - the
; kernel is really switching between them on a timer.
;
; Since Milestone 16 all three demo tasks are assembled at the SAME ORG.
; `multitask` gives each of them its own address space, so one virtual
; address means three different physical pages - which is the point the
; demo now makes. Before Milestone 16 they shared one page directory and
; had to be given distinct addresses instead.
;
; ORG must match the load address scheduler_spawn_process() is given for
; this task in kernel/shell.c's `multitask` command (0x50000000) - flat,
; non-relocatable binary, same convention as userland/user_hello.s.
;
; To regenerate kernel/task_a_blob.c after editing this file:
;   nasm -f bin userland/task_a.s -o userland/task_a.bin
;   python3 userland/embed_tasks.py

BITS 32
ORG 0x50000000

_start:
    mov esi, 12          ; iteration count
.loop:
    mov eax, 4            ; Linux SYS_write
    mov ebx, 1            ; fd 1 = stdout
    mov ecx, msg
    mov edx, msg_len
    int 0x80

    mov edi, 3000000      ; busy-wait spin between prints (see comment
.spin:                     ; above) - long enough that one scheduler
    dec edi                ; time slice covers only a fraction of it
    jnz .spin

    dec esi
    jnz .loop

    mov eax, 1             ; Linux SYS_exit
    xor ebx, ebx
    int 0x80

.halt_loop:
    jmp .halt_loop          ; should never be reached: sys_exit doesn't return

msg: db "[A]", 10, 0
msg_len equ $ - msg - 1   ; Linux write() takes a length, not a
                          ; NUL-terminated string; the -1 drops the
                          ; terminator, which is only there because
                          ; the old Novaris SYS_WRITE needed it.

