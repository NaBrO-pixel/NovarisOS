#ifndef GDT_H
#define GDT_H

#include <stdint.h>

/* We define our own flat GDT rather than relying on whatever GRUB left set
 * up. "Flat" means each segment spans the entire 4GB address space, so in
 * practice segmentation does nothing and we rely on paging later for
 * protection/isolation - this is standard practice for modern x86 kernels. */

void gdt_install(void);

/* Updates the TSS's ring-0 stack pointer (esp0). The CPU loads esp/ss
 * from here automatically whenever an interrupt or syscall arrives while
 * running in ring 3, so this must point at a valid, currently-unused
 * kernel stack before any user-mode code runs. */
void gdt_set_kernel_stack(uint32_t esp0);

#endif
