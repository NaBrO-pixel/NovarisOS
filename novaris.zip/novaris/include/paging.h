#ifndef PAGING_H
#define PAGING_H

#include <stdint.h>

#define PAGE_PRESENT 0x1
#define PAGE_RW      0x2
#define PAGE_USER    0x4

/* Replaces boot.s's coarse 4MB-page bootstrap mapping with a real
 * 4KB-granularity page directory: identity-maps the first 4MB (so the
 * VGA buffer and low-memory structures keep working) and maps the
 * kernel's own physical image at its higher-half virtual addresses.
 * Must run after pmm_init(), since it allocates page-table frames
 * through the physical memory manager. */
void paging_init(uint32_t kernel_physical_start, uint32_t kernel_physical_end);

/* Maps a single 4KB page. virt_addr and phys_addr must both be
 * page-aligned. Allocates a new page table via the PMM if needed. */
void paging_map_page(uint32_t virt_addr, uint32_t phys_addr, uint32_t flags);

/* Removes a mapping and invalidates the TLB entry for it. Does not free
 * the underlying physical frame - call pmm_free_frame() separately if
 * that's what you want. */
void paging_unmap_page(uint32_t virt_addr);

#endif
