#ifndef IDT_H
#define IDT_H

#include <stdint.h>

/* Registers pushed by our common ISR/IRQ stub, in the order they land on
 * the stack. This struct lets C handlers inspect what the CPU was doing
 * when the interrupt fired. */
typedef struct registers {
    uint32_t ds;
    uint32_t edi, esi, ebp, esp_dummy, ebx, edx, ecx, eax; /* pusha order */
    uint32_t int_no, err_code;
    uint32_t eip, cs, eflags, useresp, ss;
} registers_t;

typedef void (*isr_handler_t)(registers_t*);

void idt_install(void);

/* Lets drivers (PIT, keyboard, ...) register a handler for a specific
 * interrupt number (0-31 exceptions, 32-47 remapped IRQs). */
void register_interrupt_handler(uint8_t n, isr_handler_t handler);

#endif
