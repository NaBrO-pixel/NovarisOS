#ifndef PE_H
#define PE_H

#include <stdint.h>

/* Milestone 8b - basic PE32 (.exe) loading.
 *
 * Scope, spelled out honestly (see ROADMAP.md): this parses and loads a
 * 32-bit PE image's sections at their specified addresses and jumps to
 * its entry point - the same "get bytes into memory at the right
 * addresses and start executing" job elf.c does for ELF. It does NOT
 * implement:
 *   - the Windows API (kernel32/user32/etc) - there is no DLL loader,
 *     no import-table resolution, nothing for a real .exe to call into
 *   - the PE relocation table (base relocs) - images must run happily
 *     at their preferred ImageBase
 *   - PE32+ (64-bit) images
 *
 * Because of this, pe_load() deliberately *refuses* to load any image
 * whose import directory is non-empty, rather than mapping it and
 * jumping to an entry point that will immediately fault trying to call
 * an unresolved kernel32 function. That would look like progress
 * ("it loaded!") while actually being a crash a few instructions later.
 * A real unmodified Windows .exe will always hit this check and be
 * rejected - running one requires the Win32 API surface described in
 * ROADMAP.md's Milestone 8 Path A/B discussion, which this does not
 * attempt. What *does* work: a specially-built PE with no imports (see
 * userland/pe_test/), which proves the header parsing, section mapping,
 * and entry jump are all real and correct.
 */

#define IMAGE_DOS_SIGNATURE 0x5A4D /* "MZ" */
#define IMAGE_NT_SIGNATURE  0x00004550u /* "PE\0\0" */

#define IMAGE_FILE_MACHINE_I386 0x14c
#define IMAGE_NT_OPTIONAL_HDR32_MAGIC 0x10b

typedef struct {
    uint16_t e_magic;
    uint8_t  e_ignore1[58]; /* rest of the DOS header we don't care about */
    uint32_t e_lfanew;      /* file offset to the PE signature */
} __attribute__((packed)) dos_header_t;

typedef struct {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} __attribute__((packed)) coff_header_t;

typedef struct {
    uint32_t VirtualAddress;
    uint32_t Size;
} __attribute__((packed)) data_directory_t;

#define IMAGE_DIRECTORY_ENTRY_IMPORT 1
#define IMAGE_NUMBEROF_DIRECTORY_ENTRIES 16

typedef struct {
    uint16_t Magic;
    uint8_t  MajorLinkerVersion;
    uint8_t  MinorLinkerVersion;
    uint32_t SizeOfCode;
    uint32_t SizeOfInitializedData;
    uint32_t SizeOfUninitializedData;
    uint32_t AddressOfEntryPoint;
    uint32_t BaseOfCode;
    uint32_t BaseOfData;
    uint32_t ImageBase;
    uint32_t SectionAlignment;
    uint32_t FileAlignment;
    uint16_t MajorOperatingSystemVersion;
    uint16_t MinorOperatingSystemVersion;
    uint16_t MajorImageVersion;
    uint16_t MinorImageVersion;
    uint16_t MajorSubsystemVersion;
    uint16_t MinorSubsystemVersion;
    uint32_t Win32VersionValue;
    uint32_t SizeOfImage;
    uint32_t SizeOfHeaders;
    uint32_t CheckSum;
    uint16_t Subsystem;
    uint16_t DllCharacteristics;
    uint32_t SizeOfStackReserve;
    uint32_t SizeOfStackCommit;
    uint32_t SizeOfHeapReserve;
    uint32_t SizeOfHeapCommit;
    uint32_t LoaderFlags;
    uint32_t NumberOfRvaAndSizes;
    data_directory_t DataDirectory[IMAGE_NUMBEROF_DIRECTORY_ENTRIES];
} __attribute__((packed)) optional_header32_t;

typedef struct {
    uint8_t  Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLinenumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLinenumbers;
    uint32_t Characteristics;
} __attribute__((packed)) section_header_t;

/* Returns 1 if `image` has valid MZ/PE signatures, is a 32-bit PE32
 * (not PE32+/x64) image for IMAGE_FILE_MACHINE_I386, and all of its
 * header offsets fall inside `size`. Does not check the import table -
 * see pe_load(). */
int pe_is_valid(const uint8_t* image, uint32_t size);

/* Reason pe_load() failed, so callers/the shell can print something
 * more useful than a flat "nope". */
typedef enum {
    PE_OK = 0,
    PE_ERR_BAD_HEADER,
    PE_ERR_HAS_IMPORTS,   /* needs a Win32 API we don't provide - see pe.h */
    PE_ERR_OUT_OF_MEMORY,
    PE_ERR_BAD_SECTION,
} pe_load_result_t;

/* Maps every section at ImageBase+VirtualAddress (PAGE_USER|PAGE_RW),
 * zero-fills VirtualSize bytes then copies in SizeOfRawData bytes of
 * file data, same shape as elf_load(). Refuses (PE_ERR_HAS_IMPORTS)
 * if the image's import directory is non-empty - see the big comment
 * above. On success returns PE_OK and the entry point (ImageBase +
 * AddressOfEntryPoint) in *out_entry. */
pe_load_result_t pe_load(const uint8_t* image, uint32_t size, uint32_t* out_entry);

#endif
