#ifndef PROCESS_H
#define PROCESS_H

#include <stdint.h>

/* Implemented in process_asm.s. Drops into ring 3 at `entry` with
 * `user_stack_top` as the initial ESP, and blocks (from the caller's
 * point of view) until the user program calls sys_exit. */
void process_run_user_mode(uint32_t entry, uint32_t user_stack_top);

/* Implemented in process_asm.s. Called only from the sys_exit syscall
 * handler; restores the kernel stack saved by process_run_user_mode and
 * returns control to whoever called it. Never returns to its own caller. */
void process_exit_to_kernel(void) __attribute__((noreturn));

/* Maps a flat (non-relocatable) binary image at USER_LOAD_VADDR, gives it
 * a one-page user stack, and runs it via process_run_user_mode(). Used
 * both for the boot-time embedded demo and for the shell's `run`
 * command loading a program from the initrd. Blocks until it exits. */
void process_run_flat_binary(const uint8_t* image, uint32_t size);

/* Runs the boot-time embedded "hello world" demo (see
 * kernel/user_hello_blob.c), via process_run_flat_binary(). */
void process_run_demo_user_program(void);

/* Loads a real ELF32 executable (PT_LOAD segments mapped at their own
 * ELF-specified addresses - see elf.c) and runs it the same way. Returns
 * 0 without running anything if `image` isn't a loadable ELF. */
int process_run_elf(const uint8_t* image, uint32_t size);

/* Loads a PE32 (.exe) image (sections mapped at their own
 * ImageBase+RVA addresses - see pe.c) and runs it the same way. Returns
 * a pe_load_result_t (0/PE_OK on success) - see pe.h for what this can
 * and can't actually load (no Win32 API / imports). */
int process_run_pe(const uint8_t* image, uint32_t size);

#endif
