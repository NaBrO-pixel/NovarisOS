#include "pe.h"
#include "paging.h"
#include "pmm.h"

/* See the big comment in pe.h before touching this file. */

static const optional_header32_t* pe_opt_header(const uint8_t* image, uint32_t size,
                                                  const coff_header_t** out_coff) {
    if (size < sizeof(dos_header_t)) return 0;
    const dos_header_t* dos = (const dos_header_t*)image;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;

    /* e_lfanew plus a 4-byte PE signature plus the COFF header must fit. */
    if (dos->e_lfanew > size) return 0;
    if ((uint64_t)dos->e_lfanew + 4 + sizeof(coff_header_t) > size) return 0;

    const uint32_t* pe_sig = (const uint32_t*)(image + dos->e_lfanew);
    if (*pe_sig != IMAGE_NT_SIGNATURE) return 0;

    const coff_header_t* coff = (const coff_header_t*)(image + dos->e_lfanew + 4);
    if (coff->Machine != IMAGE_FILE_MACHINE_I386) return 0;
    if (coff->SizeOfOptionalHeader < sizeof(optional_header32_t)) return 0;

    uint32_t opt_off = dos->e_lfanew + 4 + sizeof(coff_header_t);
    if ((uint64_t)opt_off + sizeof(optional_header32_t) > size) return 0;

    const optional_header32_t* opt = (const optional_header32_t*)(image + opt_off);
    if (opt->Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) return 0;

    if (out_coff) *out_coff = coff;
    return opt;
}

int pe_is_valid(const uint8_t* image, uint32_t size) {
    return pe_opt_header(image, size, 0) != 0;
}

/* IMAGE_IMPORT_DESCRIPTOR, 20 bytes. A well-formed import directory is
 * an array of these terminated by one that's all zero. */
typedef struct {
    uint32_t OriginalFirstThunk;
    uint32_t TimeDateStamp;
    uint32_t ForwarderChain;
    uint32_t Name;
    uint32_t FirstThunk;
} __attribute__((packed)) import_descriptor_t;

/* rva_to_file_offset: find the section containing `rva` and translate.
 * Returns 0xFFFFFFFF (an offset that can never be valid, since it's
 * >= any real file size we'd accept) if `rva` isn't inside any
 * section - callers must treat that as "can't verify, assume unsafe". */
static uint32_t rva_to_file_offset(const section_header_t* sh, uint32_t num_sections,
                                    uint32_t rva) {
    for (uint32_t i = 0; i < num_sections; i++) {
        uint32_t vsize = sh[i].VirtualSize ? sh[i].VirtualSize : sh[i].SizeOfRawData;
        if (rva >= sh[i].VirtualAddress && rva < sh[i].VirtualAddress + vsize) {
            return sh[i].PointerToRawData + (rva - sh[i].VirtualAddress);
        }
    }
    return 0xFFFFFFFFu;
}

/* Toolchains (even for an import-free program) commonly still emit an
 * import directory containing exactly one all-zero terminator
 * descriptor - that's a non-zero Size but zero real imports. So rather
 * than trust DataDirectory[IMPORT].Size != 0, actually walk the
 * descriptor table and only flag it if some descriptor names a real
 * DLL/thunk. Returns 1 if the image needs at least one import resolved,
 * 0 if it's clean (or has no import directory at all), or -1 if the
 * directory is present but unreadable (treated as "assume unsafe" by
 * the caller). */
static int pe_has_real_imports(const uint8_t* image, uint32_t size,
                                const optional_header32_t* opt,
                                const section_header_t* sh, uint32_t num_sections) {
    if (opt->NumberOfRvaAndSizes <= IMAGE_DIRECTORY_ENTRY_IMPORT) return 0;
    const data_directory_t* dir = &opt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (dir->Size == 0 || dir->VirtualAddress == 0) return 0;

    uint32_t off = rva_to_file_offset(sh, num_sections, dir->VirtualAddress);
    if (off == 0xFFFFFFFFu) return -1;

    /* Walk descriptors until the all-zero terminator, a name/thunk that
     * proves a real import, or we run off the end of the buffer. */
    for (;;) {
        if ((uint64_t)off + sizeof(import_descriptor_t) > size) return -1;
        const import_descriptor_t* d = (const import_descriptor_t*)(image + off);
        if (d->OriginalFirstThunk == 0 && d->FirstThunk == 0 && d->Name == 0) {
            return 0; /* terminator reached, nothing real before it */
        }
        return 1; /* a populated descriptor - this image needs a real DLL */
    }
}

pe_load_result_t pe_load(const uint8_t* image, uint32_t size, uint32_t* out_entry) {
    const coff_header_t* coff = 0;
    const optional_header32_t* opt = pe_opt_header(image, size, &coff);
    if (!opt) return PE_ERR_BAD_HEADER;

    uint32_t dos_lfanew = ((const dos_header_t*)image)->e_lfanew;
    uint32_t sec_off = dos_lfanew + 4 + sizeof(coff_header_t) + coff->SizeOfOptionalHeader;
    uint32_t num_sections = coff->NumberOfSections;

    if ((uint64_t)sec_off + (uint64_t)num_sections * sizeof(section_header_t) > size) {
        return PE_ERR_BAD_SECTION;
    }
    const section_header_t* sh = (const section_header_t*)(image + sec_off);

    /* Refuse anything that needs imports resolved - we have no DLLs, no
     * kernel32/user32/etc, so an image that imports from them would map
     * fine and then fault on its first API call. Better to say so up
     * front. See pe.h. */
    int imports = pe_has_real_imports(image, size, opt, sh, num_sections);
    if (imports != 0) return PE_ERR_HAS_IMPORTS;

    uint32_t base = opt->ImageBase;

    for (uint32_t i = 0; i < num_sections; i++) {
        uint32_t vsize = sh[i].VirtualSize;
        uint32_t rawsize = sh[i].SizeOfRawData;
        /* Sections with VirtualSize 0 (some linkers) fall back to the
         * on-disk size, same convention real loaders use. */
        if (vsize == 0) vsize = rawsize;
        if (vsize == 0) continue; /* nothing to map */

        if (rawsize > 0 &&
            (uint64_t)sh[i].PointerToRawData + rawsize > size) {
            return PE_ERR_BAD_SECTION;
        }

        uint32_t vaddr = base + sh[i].VirtualAddress;
        uint32_t seg_start = vaddr & ~0xFFFu;
        uint32_t seg_end = (vaddr + vsize + 0xFFFu) & ~0xFFFu;

        for (uint32_t va = seg_start; va < seg_end; va += 4096) {
            uint32_t phys = pmm_alloc_frame();
            if (!phys) return PE_ERR_OUT_OF_MEMORY;
            paging_map_page(va, phys, PAGE_PRESENT | PAGE_RW | PAGE_USER);
        }

        uint8_t* dest = (uint8_t*)vaddr;
        for (uint32_t b = 0; b < vsize; b++) dest[b] = 0;

        if (rawsize > 0) {
            /* Copy at most vsize bytes even if the file claims a larger
             * raw size - matches how memsz/filesz are handled in elf.c. */
            uint32_t copy = rawsize < vsize ? rawsize : vsize;
            const uint8_t* src = image + sh[i].PointerToRawData;
            for (uint32_t b = 0; b < copy; b++) dest[b] = src[b];
        }
    }

    *out_entry = base + opt->AddressOfEntryPoint;
    return PE_OK;
}
