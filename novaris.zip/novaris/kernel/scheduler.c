/* scheduler.c - Milestone 9: real process structures + a round-robin
 * preemptive scheduler.
 *
 * The core trick: a process that has never run yet, and a process that
 * got preempted mid-flight, can be resumed through *exactly* the same
 * code path if we make "never run yet" look like "was just interrupted".
 * isr.s's shared stub epilogue (the tail end of isr_common_stub and
 * irq_common_stub) always does the same thing to return to ring 3:
 *
 *     pop gs; pop fs; pop es; pop ds
 *     popa             ; edi,esi,ebp,(esp slot, discarded),ebx,edx,ecx,eax
 *     add esp, 8        ; skip int_no/err_code
 *     iret              ; pops eip,cs,eflags,useresp,ss
 *
 * That's a fixed layout (see registers_t in idt.h). So instead of only
 * ever restoring a *real* previously-saved frame, scheduler_spawn_flat()
 * synthesizes one by hand at the top of a fresh kernel stack, with eip =
 * the program's entry point and useresp/ss pointing at its user stack.
 * From the epilogue's point of view a brand new process and a resumed
 * one are indistinguishable - both are just "an esp value pointing at a
 * well-formed frame".
 *
 * The actual stack switch happens in isr.s itself (see the
 * `scheduler_next_esp` hook added to both stub epilogues there), not
 * here - by the time this file changes which process is "current" and
 * writes scheduler_next_esp, we're still running on the *old* process's
 * kernel stack, several C stack frames deep (syscall/irq handler ->
 * isr_handler/irq_handler -> isr_common_stub). We can't safely repoint
 * ESP out from under a live C call chain ourselves; instead we let that
 * whole chain unwind normally back to the raw asm epilogue, which is the
 * one place it's safe to swap stacks, and *it* honors the hook we left. */

#include "scheduler.h"
#include "paging.h"
#include "pmm.h"
#include "kheap.h"
#include "gdt.h"
#include "console.h"

#define MAX_PROCESSES 8
#define PROC_KSTACK_SIZE 4096u
#define PAGE_SIZE 4096u

/* Preempt every this-many PIT ticks. At the 100Hz pit_install(100) rate
 * kernel_main() uses, 2 ticks = ~20ms time slices - frequent enough that
 * a handful of tight-looping demo tasks visibly interleave their output
 * within a couple seconds, without spending most of the CPU budget on
 * scheduling overhead itself. */
#define SCHED_TICKS_PER_SLICE 2

static process_t process_table[MAX_PROCESSES];
static int process_count = 0;
static int next_pid = 1;

static process_t* current = 0;
static int active = 0;
static uint32_t tick_countdown = SCHED_TICKS_PER_SLICE;

/* Consumed by the epilogue hook added to isr.s's isr_common_stub /
 * irq_common_stub: non-zero means "switch to this kernel esp instead of
 * continuing on whatever's currently on the stack" (see the file-level
 * comment above). The asm clears it back to 0 itself once consumed. */
uint32_t scheduler_next_esp = 0;

/* Implemented in kernel/scheduler_asm.s. Mirrors process_asm.s's
 * process_run_user_mode()/process_exit_to_kernel() pair, but for
 * "run every spawned process to completion" instead of just one:
 * scheduler_bootstrap_save_and_jump() saves the caller's kernel esp/ebp
 * (into scheduler_resume_esp/ebp below) and jumps into the first
 * process's synthetic frame; scheduler_return_to_caller() unwinds back
 * to right after that call once the last process has exited. */
extern void scheduler_bootstrap_save_and_jump(uint32_t first_esp);
extern void scheduler_return_to_caller(void) __attribute__((noreturn));
uint32_t scheduler_resume_esp = 0;
uint32_t scheduler_resume_ebp = 0;

void scheduler_init(void) {
    process_count = 0;
    next_pid = 1;
    current = 0;
    active = 0;
    tick_countdown = SCHED_TICKS_PER_SLICE;
    scheduler_next_esp = 0;
}

int scheduler_is_active(void) {
    return active;
}

static void copy_name(process_t* p, const char* name) {
    int i = 0;
    while (name[i] && i < PROCESS_MAX_NAME - 1) {
        p->name[i] = name[i];
        i++;
    }
    p->name[i] = '\0';
}

/* The part every spawn shares: a kernel stack, a one-page user stack, and
 * a synthetic trap frame that makes a never-run task indistinguishable
 * from a preempted one. `entry` is where ring 3 starts; `load_pages` is
 * how many image pages this task is responsible for freeing (0 for a
 * thread, which loaded nothing of its own). Everything it maps goes into
 * whatever address space is current, which is how one function serves
 * processes and threads alike. */
static int spawn_common(const char* name, uint32_t entry, uint32_t load_vaddr,
                        uint32_t load_pages, uint32_t stack_top,
                        int owns_pd) {
    uint32_t stack_phys = pmm_alloc_frame();
    if (!stack_phys) return -1;
    paging_map_page(stack_top - PAGE_SIZE, stack_phys,
                     PAGE_PRESENT | PAGE_RW | PAGE_USER);

    uint8_t* kstack_base = (uint8_t*)kmalloc(PROC_KSTACK_SIZE);
    if (!kstack_base) return -1;
    uint32_t kstack_top = (uint32_t)kstack_base + PROC_KSTACK_SIZE;

    /* Build the synthetic initial trap frame - see the file-level
     * comment for why this makes a never-run process look, to the
     * switch code, just like one that was preempted mid-flight. */
    registers_t* frame = (registers_t*)(kstack_top - sizeof(registers_t));
    frame->ds = 0x23;               /* user data selector | RPL3 */
    frame->es = 0x23;
    frame->fs = 0x23;
    frame->gs = 0x23;
    frame->edi = 0;
    frame->esi = 0;
    frame->ebp = 0;
    frame->esp_dummy = 0;           /* popa discards this slot */
    frame->ebx = 0;
    frame->edx = 0;
    frame->ecx = 0;
    frame->eax = 0;
    frame->int_no = 0;              /* skipped by `add esp,8`, value unused */
    frame->err_code = 0;
    frame->eip = entry;             /* where ring 3 starts */
    frame->cs = 0x1B;               /* user code selector | RPL3 */
    frame->eflags = 0x202;          /* IF=1 (so this task can itself be
                                      * preempted), reserved bit 1 set */
    frame->useresp = stack_top;
    frame->ss = 0x23;

    process_t* p = &process_table[process_count++];
    p->pid = next_pid++;
    copy_name(p, name);
    p->esp = (uint32_t)frame;
    p->kernel_stack_base = (uint32_t)kstack_base;
    p->kernel_stack_top = kstack_top;
    p->load_vaddr = load_vaddr;
    p->load_pages = load_pages;
    p->stack_top = stack_top;
    p->page_directory = paging_current_address_space();
    p->owns_page_directory = owns_pd;
    p->state = PROC_READY;
    return p->pid;
}

/* Maps and copies a flat image into the current address space. Returns
 * the page count, or 0 if physical memory ran out partway (the pages it
 * did map are left for the reaper to free). */
static uint32_t load_image(const uint8_t* image, uint32_t size,
                           uint32_t load_vaddr) {
    uint32_t pages = (size + PAGE_SIZE - 1) / PAGE_SIZE;
    if (pages == 0) pages = 1;

    for (uint32_t i = 0; i < pages; i++) {
        uint32_t phys = pmm_alloc_frame();
        if (!phys) return 0;
        paging_map_page(load_vaddr + i * PAGE_SIZE, phys,
                         PAGE_PRESENT | PAGE_RW | PAGE_USER);
    }

    uint8_t* dest = (uint8_t*)load_vaddr;
    for (uint32_t i = 0; i < size; i++) dest[i] = image[i];
    return pages;
}

int scheduler_spawn_flat(const char* name, const uint8_t* image, uint32_t size,
                          uint32_t load_vaddr, uint32_t stack_top) {
    if (process_count >= MAX_PROCESSES) return -1;

    uint32_t pages = load_image(image, size, load_vaddr);
    if (!pages) return -1;

    return spawn_common(name, load_vaddr, load_vaddr, pages, stack_top, 0);
}

int scheduler_spawn_process(const char* name, const uint8_t* image,
                            uint32_t size, uint32_t load_vaddr,
                            uint32_t stack_top) {
    if (process_count >= MAX_PROCESSES) return -1;

    uint32_t caller_as = paging_current_address_space();
    uint32_t as = paging_create_address_space();
    if (!as) return -1;

    /* Load into the new address space by standing in it. Every mapping
     * spawn_common() and load_image() make goes through the ordinary
     * paging calls, which act on whatever is in CR3 - so switching here
     * is the entire mechanism, and neither of them needs to know that
     * address spaces exist. Safe because the kernel half is identical in
     * both: the image bytes are read out of a kernel buffer that is at
     * the same address either side of the switch. */
    paging_switch_address_space(as);

    uint32_t pages = load_image(image, size, load_vaddr);
    int pid = pages ? spawn_common(name, load_vaddr, load_vaddr, pages,
                                   stack_top, 1)
                    : -1;

    paging_switch_address_space(caller_as);

    if (pid < 0) paging_destroy_address_space(as);
    return pid;
}

int scheduler_spawn_thread(const char* name, uint32_t entry,
                           uint32_t stack_top) {
    if (process_count >= MAX_PROCESSES) return -1;
    /* No image, no address space: load_pages 0 says "I own no code", and
     * owns_pd 0 says "the directory I run in is somebody else's". What is
     * left - a stack and a register context - is exactly what a thread
     * is. */
    return spawn_common(name, entry, entry, 0, stack_top, 0);
}

/* Round robin: scans forward from just after `current`'s slot, wrapping,
 * returning the first non-zombie process found (which may be `current`
 * itself, if it's the only one left - callers that just marked `current`
 * a zombie rely on that state already being set before this runs, so it
 * can't be picked again). Returns 0 if every slot is a zombie. */
static process_t* pick_next_ready(void) {
    if (process_count == 0) return 0;

    int cur_idx = 0;
    for (int i = 0; i < process_count; i++) {
        if (&process_table[i] == current) {
            cur_idx = i;
            break;
        }
    }

    for (int off = 1; off <= process_count; off++) {
        int idx = (cur_idx + off) % process_count;
        if (process_table[idx].state != PROC_ZOMBIE) {
            return &process_table[idx];
        }
    }
    return 0;
}

static void switch_to(process_t* next);

void scheduler_tick(registers_t* regs) {
    if (!active || !current) return;

    if (tick_countdown > 0) {
        tick_countdown--;
        return;
    }
    tick_countdown = SCHED_TICKS_PER_SLICE;

    current->esp = (uint32_t)regs;
    current->state = PROC_READY;

    process_t* next = pick_next_ready();
    if (!next) {
        /* Shouldn't happen while active (there'd be nothing left to
         * preempt), but stay safe rather than switch to nothing. */
        current->state = PROC_RUNNING;
        return;
    }

    switch_to(next);
}

/* Makes `next` the running task. The CR3 load is the Milestone 16
 * addition, and it is safe to do here - several C frames deep, on the
 * outgoing task's kernel stack - precisely because Milestone 14 made the
 * kernel half identical in every address space: this code, this stack and
 * the frame `scheduler_next_esp` points at are all at the same addresses
 * before and after the load. Only the user half changes, and nothing on
 * the switch path touches that.
 *
 * Skipping the load when the directory is unchanged is not just an
 * optimisation - it is what makes switching between two threads of one
 * process cheap, since a CR3 write flushes the whole TLB. */
static void switch_to(process_t* next) {
    if (next->page_directory != current->page_directory) {
        paging_switch_address_space(next->page_directory);
    }
    current = next;
    current->state = PROC_RUNNING;
    gdt_set_kernel_stack(current->kernel_stack_top);
    scheduler_next_esp = current->esp;
}

/* Frees every process's kernel stack and mapped user pages, then resets
 * the table. Only ever called after every process is a zombie and we've
 * fully unwound off their kernel stacks (from scheduler_run_until_idle,
 * back on the original caller's own stack) - never from inside a
 * process's own exit path, which would mean freeing memory out from
 * under code still (about to be) executing on it. */
/* Unmaps a page *and* hands its frame back to the PMM. Unmapping alone
 * only removes the translation - the frame stays marked in use forever,
 * which is how `multitask` came to lose six frames every time it ran.
 * Found while checking that Milestone 15's address spaces gave back
 * everything they took; the bug itself dates from Milestone 9. */
static void free_user_page(uint32_t virt) {
    uint32_t pte = paging_get_entry(virt);
    paging_unmap_page(virt);
    if (pte & PAGE_PRESENT) pmm_free_frame(pte & ~0xFFFu);
}

static void reap_all(void) {
    uint32_t caller_as = paging_current_address_space();

    /* Two passes, because a task's pages can only be unmapped from inside
     * its own address space, and a directory cannot be destroyed while it
     * is the one loaded in CR3. */
    for (int i = 0; i < process_count; i++) {
        process_t* p = &process_table[i];
        paging_switch_address_space(p->page_directory);
        for (uint32_t pg = 0; pg < p->load_pages; pg++) {
            free_user_page(p->load_vaddr + pg * PAGE_SIZE);
        }
        free_user_page(p->stack_top - PAGE_SIZE);
        kfree((void*)p->kernel_stack_base);
    }

    paging_switch_address_space(caller_as);

    for (int i = 0; i < process_count; i++) {
        process_t* p = &process_table[i];
        /* Only the task that created a directory destroys it. Threads
         * share a sibling's and must not, and a task spawned into a
         * directory the caller owns must leave it to the caller. */
        if (p->owns_page_directory) {
            paging_destroy_address_space(p->page_directory);
        }
    }

    process_count = 0;
}

void scheduler_exit_current(void) {
    if (!current) return;

    current->state = PROC_ZOMBIE;
    process_t* next = pick_next_ready();

    if (!next) {
        /* Last process standing just exited: nothing left to switch to.
         * Discard this entire (deeply-nested) C call chain the same way
         * process.c's process_exit_to_kernel() discards its own -
         * jump straight back to whoever called
         * scheduler_bootstrap_save_and_jump(), as if that call had just
         * returned normally. Does not return here. */
        active = 0;
        current = 0;
        scheduler_return_to_caller();
        __builtin_unreachable();
    }

    switch_to(next);
    /* Returns normally: back up through the syscall handler -> isr
     * dispatch -> isr_common_stub, whose epilogue performs the actual
     * switch once it sees scheduler_next_esp set. */
}

void scheduler_run_until_idle(void) {
    if (process_count == 0) return;

    uint32_t caller_as = paging_current_address_space();

    active = 1;
    tick_countdown = SCHED_TICKS_PER_SLICE;
    current = &process_table[0];
    current->state = PROC_RUNNING;
    gdt_set_kernel_stack(current->kernel_stack_top);
    /* The first task is entered directly rather than through switch_to(),
     * so its address space has to be loaded by hand here. */
    paging_switch_address_space(current->page_directory);

    /* Blocks here - from this function's own point of view - until every
     * spawned process has called sys_exit. See scheduler_asm.s. */
    scheduler_bootstrap_save_and_jump(current->esp);

    /* Control lands here on whichever task exited last, so CR3 still
     * holds *its* directory. reap_all() walks every address space and
     * comes back to whatever is current when it starts, so put the
     * caller's back first. */
    paging_switch_address_space(caller_as);
    reap_all();
}
