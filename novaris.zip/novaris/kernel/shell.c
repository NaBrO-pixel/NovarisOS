#include <stdint.h>
#include "shell.h"
#include "console.h"
#include "keyboard.h"
#include "pit.h"
#include "pmm.h"
#include "process.h"
#include "vfs.h"
#include "kheap.h"
#include "elf.h"
#include "pe.h"
#include "scheduler.h"
#include "task_a.h"
#include "task_b.h"
#include "task_c.h"

#define CMD_BUFFER_SIZE 128

/* No libc here, so tiny hand-rolled helpers again. */
static int streq(const char* a, const char* b) {
    while (*a && *b) {
        if (*a != *b) return 0;
        a++;
        b++;
    }
    return *a == *b;
}

static int starts_with(const char* s, const char* prefix) {
    while (*prefix) {
        if (*s != *prefix) return 0;
        s++;
        prefix++;
    }
    return 1;
}

static void print_uint(uint32_t n) {
    char buf[11];
    int i = 10;
    buf[10] = '\0';
    if (n == 0) {
        terminal_writestring("0");
        return;
    }
    while (n > 0 && i > 0) {
        buf[--i] = '0' + (n % 10);
        n /= 10;
    }
    terminal_writestring(&buf[i]);
}

static void print_prompt(void) {
    terminal_writestring_color("novaris", VGA_COLOR_LIGHT_CYAN);
    terminal_writestring_color("> ", VGA_COLOR_LIGHT_GREY);
}

static void run_command(char* line) {
    while (*line == ' ') line++; /* skip leading spaces */
    if (*line == '\0') return;   /* empty line: just re-prompt */

    if (streq(line, "help")) {
        terminal_writestring("Available commands:\n");
        terminal_writestring("  help    - show this list\n");
        terminal_writestring("  clear   - clear the screen\n");
        terminal_writestring("  about   - about Novaris\n");
        terminal_writestring("  uptime  - timer ticks since boot\n");
        terminal_writestring("  meminfo - physical memory frame usage\n");
        terminal_writestring("  ls      - list files on the initrd\n");
        terminal_writestring("  cat     - print a file, e.g. cat hello.txt\n");
        terminal_writestring("  run     - run a program, e.g. run hello_c.bin\n");
        terminal_writestring("            (also loads plain ELF and PE32 .exe files -\n");
        terminal_writestring("            see ROADMAP.md Milestone 8 for what's not supported)\n");
        terminal_writestring("  runuser - run the demo ring-3 user program\n");
        terminal_writestring("  multitask - run 3 demo programs concurrently under\n");
        terminal_writestring("            real preemptive scheduling (see ROADMAP.md\n");
        terminal_writestring("            Milestone 9) - watch their output interleave\n");
        terminal_writestring("  echo    - print text back\n");
    } else if (streq(line, "clear")) {
        terminal_initialize();
    } else if (streq(line, "about")) {
        terminal_writestring_color("Novaris", VGA_COLOR_LIGHT_CYAN);
        terminal_writestring(" -- a hobby OS kernel. See ROADMAP.md for progress.\n");
    } else if (streq(line, "uptime")) {
        terminal_writestring("Ticks since boot: ");
        print_uint(pit_get_ticks());
        terminal_writestring("\n");
    } else if (streq(line, "meminfo")) {
        terminal_writestring("Physical frames: ");
        print_uint(pmm_free_frames());
        terminal_writestring(" free / ");
        print_uint(pmm_total_frames());
        terminal_writestring(" total (");
        print_uint(pmm_free_frames() * 4);
        terminal_writestring("KB free)\n");
    } else if (streq(line, "ls")) {
        if (!vfs_root) {
            terminal_writestring("No filesystem mounted.\n");
        } else {
            uint32_t idx = 0;
            vfs_node_t* n;
            while ((n = vfs_readdir(vfs_root, idx))) {
                terminal_writestring("  ");
                terminal_writestring(n->name);
                terminal_writestring("  (");
                print_uint(n->length);
                terminal_writestring(" bytes)\n");
                idx++;
            }
            if (idx == 0) terminal_writestring("(no files)\n");
        }
    } else if (starts_with(line, "cat")) {
        const char* fname = line + 3;
        while (*fname == ' ') fname++;
        vfs_node_t* n = vfs_root ? vfs_finddir(vfs_root, fname) : 0;
        if (*fname == '\0') {
            terminal_writestring("usage: cat <filename>\n");
        } else if (!n) {
            terminal_writestring_color("File not found: ", VGA_COLOR_LIGHT_RED);
            terminal_writestring(fname);
            terminal_writestring("\n");
        } else {
            uint8_t* buf = (uint8_t*)kmalloc(n->length + 1);
            uint32_t r = vfs_read(n, 0, n->length, buf);
            buf[r] = '\0';
            terminal_writestring((char*)buf);
            terminal_writestring("\n");
            kfree(buf);
        }
    } else if (streq(line, "runuser")) {
        process_run_demo_user_program();
        terminal_writestring("Back in the shell.\n");
    } else if (starts_with(line, "run")) {
        const char* fname = line + 3;
        while (*fname == ' ') fname++;
        vfs_node_t* n = vfs_root ? vfs_finddir(vfs_root, fname) : 0;
        if (*fname == '\0') {
            terminal_writestring("usage: run <filename>\n");
        } else if (!n) {
            terminal_writestring_color("File not found: ", VGA_COLOR_LIGHT_RED);
            terminal_writestring(fname);
            terminal_writestring("\n");
        } else {
            uint8_t* buf = (uint8_t*)kmalloc(n->length);
            vfs_read(n, 0, n->length, buf);
            if (elf_is_valid(buf, n->length)) {
                if (!process_run_elf(buf, n->length)) {
                    terminal_writestring_color("Failed to load ELF: ", VGA_COLOR_LIGHT_RED);
                    terminal_writestring(fname);
                    terminal_writestring("\n");
                }
            } else if (pe_is_valid(buf, n->length)) {
                int r = process_run_pe(buf, n->length);
                if (r != PE_OK) {
                    terminal_writestring_color("Failed to load PE: ", VGA_COLOR_LIGHT_RED);
                    terminal_writestring(fname);
                    if (r == PE_ERR_HAS_IMPORTS) {
                        terminal_writestring("\n  (imports a Win32 API this OS doesn't");
                        terminal_writestring(" implement - see ROADMAP.md Milestone 8)\n");
                    } else {
                        terminal_writestring(" (malformed PE image)\n");
                    }
                }
            } else {
                process_run_flat_binary(buf, n->length);
            }
            kfree(buf);
            terminal_writestring("Back in the shell.\n");
        }
    } else if (streq(line, "multitask")) {
        terminal_writestring_color("[kernel] ", VGA_COLOR_LIGHT_GREEN);
        terminal_writestring("Spawning 3 demo processes under the preemptive scheduler...\n");

        /* Distinct, non-overlapping load addresses - see scheduler.h's
         * top-of-file comment for why concurrently-scheduled tasks can't
         * share USER_LOAD_VADDR (0x40000000, used by `run`/`runuser`)
         * the way single-process programs do: there's still only one
         * shared page directory, so "concurrent" here means "distinct
         * addresses", not "isolated address spaces". */
        int pa = scheduler_spawn_flat("task_a", task_a_bin, task_a_bin_len,
                                       0x50000000u, 0x50100000u);
        int pb = scheduler_spawn_flat("task_b", task_b_bin, task_b_bin_len,
                                       0x50200000u, 0x50300000u);
        int pc = scheduler_spawn_flat("task_c", task_c_bin, task_c_bin_len,
                                       0x50400000u, 0x50500000u);

        if (pa < 0 || pb < 0 || pc < 0) {
            terminal_writestring_color("Failed to spawn one or more demo processes.\n", VGA_COLOR_LIGHT_RED);
        } else {
            terminal_writestring("PIDs: ");
            print_uint((uint32_t)pa);
            terminal_writestring(", ");
            print_uint((uint32_t)pb);
            terminal_writestring(", ");
            print_uint((uint32_t)pc);
            terminal_writestring(" - if you see their tags interleaved below\n");
            terminal_writestring("rather than grouped, the timer is really preempting them:\n\n");
            scheduler_run_until_idle();
            terminal_writestring("\n");
            terminal_writestring_color("[kernel] ", VGA_COLOR_LIGHT_GREEN);
            terminal_writestring("All demo processes exited. Back in the shell.\n");
        }
    } else if (starts_with(line, "echo")) {
        const char* rest = line + 4;
        while (*rest == ' ') rest++;
        terminal_writestring(rest);
        terminal_writestring("\n");
    } else {
        terminal_writestring_color("Unknown command: ", VGA_COLOR_LIGHT_RED);
        terminal_writestring(line);
        terminal_writestring("\n(type 'help' for a list)\n");
    }
}

void shell_run(void) {
    char buffer[CMD_BUFFER_SIZE];
    uint32_t len = 0;

    terminal_writestring("\nType 'help' for a list of commands.\n");
    print_prompt();

    for (;;) {
        char c = keyboard_getchar();

        if (c == '\n') {
            terminal_putchar('\n');
            buffer[len] = '\0';
            run_command(buffer);
            len = 0;
            print_prompt();
        } else if (c == '\b') {
            if (len > 0) {
                len--;
                terminal_backspace();
            }
        } else if (len < CMD_BUFFER_SIZE - 1) {
            buffer[len++] = c;
            terminal_putchar(c);
        }
    }
}
