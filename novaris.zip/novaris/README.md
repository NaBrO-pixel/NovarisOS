# Novaris

A real, from-scratch, bootable x86 operating system — built incrementally,
one subsystem at a time. This is legally and entirely yours: every line is
either written here or copied from public-domain reference material (the
Multiboot spec), no Windows/macOS/Linux source is used or referenced.

This is **not** a clone of Windows/macOS/Linux — those are billions of lines
of code built by huge teams over decades, and legally reimplementing their
exact behavior (like ReactOS does for Windows) requires careful clean-room
engineering specifically to avoid copyright issues. What we're doing instead
is building a real, simple, original OS the way every OS starts: a
bootloader hands off to a kernel, and the kernel grows from there. Over time
you can shape it to *feel* like whichever OS inspires you (windowing system,
shell conventions, UI style) without copying anyone's code.

## Current status: Milestone 2 complete ✅

- [x] Multiboot-compliant bootloader handoff (via GRUB)
- [x] 32-bit protected mode kernel entry (hand-written assembly stub)
- [x] Freestanding C kernel (no libc — we own the whole stack)
- [x] VGA text-mode driver (colors, scrolling, write/writeline)
- [x] Reads memory map info passed by the bootloader
- [x] Builds to a bootable `.iso` and verified booting in QEMU
- [x] Our own flat GDT (kernel + user code/data segments)
- [x] Our own IDT with handlers for all 32 CPU exceptions
- [x] 8259 PIC remapped so hardware IRQs land on vectors 32-47
- [x] Interrupts enabled, verified with a live `int3` round trip in QEMU

See `ROADMAP.md` for what's built and what's next, in order.

## Project layout

```
novaris/
├── boot/boot.s          # Assembly entry point + Multiboot header
├── kernel/
│   ├── kernel.c          # kernel_main() - C entry point
│   ├── vga.c              # VGA text-mode display driver
│   ├── gdt.c / gdt_flush.s   # Global Descriptor Table
│   ├── idt.c / idt_flush.s   # Interrupt Descriptor Table + dispatch
│   ├── isr.s               # Exception/IRQ entry stubs (asm)
│   └── pic.c                # 8259 PIC remap + EOI
├── include/
│   ├── vga.h
│   ├── multiboot.h        # Multiboot info structures
│   ├── gdt.h / idt.h / pic.h
│   └── io.h                # inb/outb port I/O helpers
├── linker.ld              # Places the kernel at the 1MB mark
├── grub.cfg                # GRUB menu config baked into the ISO
├── Makefile
└── ROADMAP.md              # Ordered plan for what to build next
```

## Building

You need: `nasm`, `gcc` (with 32-bit support), `ld`, `grub-mkrescue`,
`xorriso`, `mtools`. On Ubuntu/Debian:

```bash
apt-get install nasm grub-pc-bin grub-common xorriso mtools qemu-system-x86 build-essential
```

Then:

```bash
make          # builds build/novaris.bin and novaris.iso
```

## Running it

```bash
make run                 # opens a QEMU window (needs a display)
qemu-system-i386 -cdrom novaris.iso   # same thing, manually
```

If you're on a headless machine (like this sandbox), take a screenshot
instead:

```bash
qemu-system-i386 -cdrom novaris.iso -display none -vga std \
    -monitor unix:qemu-mon.sock,server,nowait &
# then, via the monitor socket, send: screendump screenshot.ppm
```

You can also burn `novaris.iso` to a USB stick with a tool like `dd` or Rufus
and boot a **real PC** from it — that's genuinely how far this goes.

## Why it's structured this way

- **Multiboot instead of a hand-written bootloader**: writing your own
  16-bit real-mode bootloader (disk reads, A20 line, GDT, protected mode
  switch) is a whole rabbit hole on its own. Using GRUB via the Multiboot
  spec is what most hobby OS projects (and this one) do first, so we can
  focus energy on the kernel. Writing a custom bootloader is a legitimate
  later milestone if you want it (see ROADMAP.md).
- **C, not the assembly the whole way**: after the tiny entry stub, we
  switch to C as fast as possible because it's dramatically more
  productive for everything else (drivers, memory management, data
  structures).
- **No libc**: a hosted OS's libc assumes an OS underneath it (for
  malloc, file I/O, etc.) — we *are* the OS, so we write our own minimal
  primitives as we need them.
